package home;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.junit.Assert;

import browser.Browser;
import locators.Locators;
import ss.Screenshot;

public class Home extends Browser{
	
	public void details() throws Exception{
		String a[]=new String[15];
		String b[]=new String[15];
		int j=0;
		for(int i=0;i<15;i++) {
			
			j=i+1;
			Thread.sleep(500);
			a[i]=driver.findElement(By.xpath("/html/body/div[3]/div[2]/div[1]/div[2]/div/div/div/div["+j+"]/a/p[1]")).getText();
			b[i]=driver.findElement(By.xpath("/html/body/div[3]/div[2]/div[1]/div[2]/div/div/div/div["+j+"]/a/p[2]")).getText();
			System.out.println(a[i]);
			System.out.println(b[i]);
			if(i==5||i==11) {
				Thread.sleep(2000);
				driver.findElement(By.xpath("//*[@id=\"categories_carousel\"]/button[2]")).click();
			}
		}
	}
	
	public void browseList() throws Exception{
		WebElement browse=Locators.browseList();
		browse.click();
	}
	
	public void openList() throws Exception{
		WebElement open=Locators.openList();
		open.click();
		Thread.sleep(1000);
	}
	
	public void seemorePage() throws Exception{
		Thread.sleep(2000);
		WebElement seemore=Locators.seemorePage();
		seemore.click();
		Thread.sleep(1000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(3000);
	}
	
	public static void assert1() throws Exception {			
		WebElement count = Locators.countTamil();
		String str = count.getText();
		String str1=str.substring(0, str.length()-6);
		String str2=str1.replace(",", "");
		int number=Integer.parseInt(str2);
		int other=1;
		try {
			Assert.assertTrue((number>other) ? true : false);
			System.out.println("\nPass");
			} catch (AssertionError e) 
			{
			System.out.println("\nFail");
			}
	}

	public static void main(String args[]) throws Exception{
		
		Home obj =new Home();
		setDriver();
		getUrl();
		
		obj.details();
		obj.browseList();
		obj.openList();
		obj.seemorePage();
		Screenshot.screenShot();
		assert1();
		closeBrowser();
	}

}
