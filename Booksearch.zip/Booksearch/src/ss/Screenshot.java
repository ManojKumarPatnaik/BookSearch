package ss;

import java.io.IOException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.OutputType;
import java.io.File;
import org.apache.commons.io.FileUtils;

import browser.Browser;

public class Screenshot extends Browser{
	public static int i=0;
	public static void screenShot() throws IOException {
		//Converting WebDriver object to takeScreenshoot
		TakesScreenshot scrShot =((TakesScreenshot)driver); 
		/*Calling the getScreenshotAs() method to 
		 *create an image file
		 */
		File Src=scrShot.getScreenshotAs(OutputType.FILE);	
		//Giving the location
		String filePath = System.getProperty("user.dir")+"//screenshots//Screenshot"+i+".png";
		
		i++;
		//Moving image file to new destination
		File Dest=new File(filePath);	 
		//copying file at destination
		FileUtils.copyFile(Src, Dest);				
	}
}
	

