package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import browser.Browser;

public class Locators extends Browser{
	
	public Locators() throws Exception {
		super();
	}
	
	public static WebElement browseList() {
		WebElement browse=driver.findElement(By.xpath("//*[@id=\"header-bar\"]/ul[1]/li[1]"));
		return browse;
	}
	
	public static WebElement openList() {
		WebElement open=driver.findElement(By.xpath("//*[@id=\"header-bar\"]/ul[1]/li[1]/div/ul/li[1]/a"));
		return open;
	}
	
	public static WebElement seemorePage() {
		WebElement seemore=driver.findElement(By.xpath("//*[@id=\"subjectsPage\"]/ul[13]/li[9]/a"));
		return seemore;
	}
	
	public static WebElement selectLan() {
		WebElement select=driver.findElement(By.xpath("//*[@id=\"contentBody\"]/ul/li[39]/a"));
		return select;
	}
	
	public static WebElement countTamil(){
		WebElement count = driver.findElement(By.xpath("//*[@id=\"contentBody\"]/ul/li[39]/span/b"));
		return count;
	}

}
